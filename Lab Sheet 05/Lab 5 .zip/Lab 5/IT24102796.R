setwd("/Users/thevaraghav/Documents/RStudio/Lab 5")
getwd()

Delivery_Times <- read.table("Exercise - Lab 05.txt",header=TRUE)

head(Delivery_Times)

names(Delivery_Times) <- "Delivery_Time"


Delivery_Times$Delivery_Time <- as.numeric(Delivery_Times$Delivery_Time)


breaks <- seq(20, 70, length.out = 10)


hist(Delivery_Times$Delivery_Time,
     breaks = breaks,
     right = FALSE,
     col = "skyblue",
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")


freq <- hist(Delivery_Times$Delivery_Time,
             breaks = breaks,
             right = FALSE,
             plot = FALSE)


cum_freq <- cumsum(freq$counts)


plot(freq$breaks[-1], cum_freq, type = "o", col = "blue",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")

