setwd("/Users/thevaraghav/Desktop/PS_Lab7")

# Exercise 1


punif(25,min=0,max=40,lower.tail=TRUE) - punif(10,min=0,max=40,lower.tail=TRUE)

# Exercise 2

pexp(2,rate = 1/3,lower.tail = TRUE)

# Exercise 3

#part1

1-pnorm(130,mean=100,sd=15,lower.tail = FALSE)

#part2

qnorm(0.95,mean=100,sd=15,lower.tail = TRUE)




